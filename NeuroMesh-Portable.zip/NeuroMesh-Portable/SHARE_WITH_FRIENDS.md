# 🧠 NeuroMesh - Neural Intelligence Network

## ⚠️ ANTIVIRUS WARNING - PLEASE READ!

**NeuroMesh will be flagged as a virus** - this is a **FALSE POSITIVE**!

### Why this happens:
- NeuroMesh opens network ports for AI communication
- The executable isn't digitally signed (costs $300/year)
- It's new software that antivirus doesn't recognize

### ✅ How to fix (REQUIRED):

**Windows Defender:**
1. Open Windows Security → Virus & threat protection
2. Click "Manage settings" 
3. Click "Add or remove exclusions"
4. Add this entire folder as an exclusion

**Other Antivirus:**
- Add this folder to exclusions/whitelist
- See ANTIVIRUS_GUIDE.md for specific instructions

### 🚀 How to run:
1. **FIRST**: Add folder to antivirus exclusions
2. **THEN**: Double-click `start-neuromesh.bat`
3. **OPEN**: http://localhost:8080/app/

### 🔒 Is it safe?
- **YES!** 100% safe and open source
- Code available at: https://github.com/PathanWasim/LLM-Network
- Built by Wasim for AI networking
- No malware, just peer-to-peer AI communication

**Trust me, add the exclusion and enjoy the neural network!** 🧠✨